package com.barracuda.sre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarracudaApplicationTests {

    @Test
    void contextLoads() {
    }

}
